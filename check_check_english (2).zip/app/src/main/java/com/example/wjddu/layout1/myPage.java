package com.example.wjddu.layout1;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class myPage extends AppCompatActivity {

    TextView user;
    GridView gv1;
    List<String> list = new ArrayList<String>();

    List<String> urId = new ArrayList<String>();
    List<String> test = new ArrayList<String>();

    //List<String> date = new ArrayList<String>();
    //String urId[] = null;
    URL[] url = null;
    Bitmap[] bitmap =null;

    private FirebaseDatabase mDatabase;
    private DatabaseReference mReference;


//    String[] date = {"2019-08-27","2019-28-27","2019-08-28"};  //DB에서 받아올 동영상의 시청 날짜
//    String[] uId ={"https://www.youtube.com/watch?v=72v7c8mxBQQ",
//            "https://www.youtube.com/watch?v=yIADPHu2QJE",
//            "https://www.youtube.com/watch?v=TpLXayxZ98g"};  //DB에서 받아올 동영상의 주소
//    Bitmap[] bitmap = new Bitmap[uId.length];
//    URL[] url = new URL[uId.length];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page);

        user = findViewById(R.id.user);
        gv1 = findViewById(R.id.gv1);

        Intent intent = getIntent();
        String userEmail = intent.getStringExtra("email");
        String userName = userEmail.substring(0,userEmail.indexOf("@"));
        user.setText(userName + "님");

        // 1. 파이어베이스 연결 - DB Connection
        mDatabase = FirebaseDatabase.getInstance();

        // 2. CRUD 작업의 기준이 되는 노드를 레퍼러느로 가져온다.
        mReference = mDatabase.getReference("users");


//    데이터베이스 읽기 #3. ChildEventListener
        mReference.orderByChild("userEmail").equalTo(userEmail).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                int i = 0;
                for(DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    String msg2 = snapshot.getValue().toString();


                    if(i%3==0){
                        //date[i/3] = msg2;
                        list.add(msg2);
                    }else if(i%3==1){
                        urId.add(msg2);
                    }
                    i++;
//                        Array.add(msg2);

                }


            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        Thread mThread = new Thread(){
            @Override
            public void run() {
                for(int i=0;i<urId.size();i++){
                    String uId = "https://img.youtube.com/vi/"+ urId.get(i) + "/" + "sddefault.jpg";  //유튜브 썸네일 불러오는 방법

                    try {
                        url[i] = new URL(uId);

                        HttpURLConnection conn = (HttpURLConnection) url[i].openConnection();
                        conn.setDoInput(true);
                        conn.connect();

                        InputStream is = conn.getInputStream();
                        bitmap[i] = BitmapFactory.decodeStream(is);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
        mThread.start();

        try{
            mThread.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        setTitle("My Page");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        MyGridAdapter adapter = new  MyGridAdapter(this);
        gv1.setAdapter(adapter);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                super.onBackPressed();
                return true;
        }
        return (super.onOptionsItemSelected(item));
    }



    public class MyGridAdapter extends BaseAdapter{
        Context context;


        MyGridAdapter(Context c){
            context = c;
        };

        public int getCount() {return urId.size(); }

        @Override
        public Object getItem(int i) {return null;}

        @Override
        public long getItemId(int i) {return 0;}

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setLayoutParams(new LinearLayout.LayoutParams(-2,-1));

            ImageView iView = new ImageView(context);
            iView.setLayoutParams(new LinearLayout.LayoutParams(400, 300));
            iView.setImageBitmap(bitmap[urId.size() - (i + 1)]);
            iView.setPadding(20,5,25,5);

            TextView tView = new TextView(context);
            tView.setLayoutParams(new LinearLayout.LayoutParams(400,300));
            //tView.setText(list.get(urId.size() - (i + 1)));
            tView.setText(test.get(i));
            tView.setTextSize(20);
            tView.setPadding(5,200,5,5);


            layout.addView(iView);
            layout.addView(tView);

            final int pos = i;
            iView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(),vlearn.class);
                    intent.putExtra("value",urId.get(urId.size() - (pos + 1)));
                    startActivity(intent);
                }
            });

            return layout;


        }
    }
}
